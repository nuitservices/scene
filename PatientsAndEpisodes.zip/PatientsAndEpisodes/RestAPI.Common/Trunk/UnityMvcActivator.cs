using Microsoft.Practices.Unity.Mvc;
using RestAPI.Common.Trunk;
using System.Linq;
using System.Web.Mvc;

[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(RestAPI.Common.Trunk.UnityWebActivator), "Start")]
[assembly: WebActivatorEx.ApplicationShutdownMethod(typeof(RestAPI.Common.Trunk.UnityWebActivator), "Shutdown")]

namespace RestAPI.Common.Trunk
{
    /// <summary>Provides the bootstrapping for integrating Unity with ASP.NET MVC.</summary>00
    public class UnityWebActivator
    {
        /// <summary>Integrates Unity when the application starts.</summary>
        public static void Start() 
        {
            // auto-builds
            var container = Container.Current;

            FilterProviders.Providers.Remove(FilterProviders.Providers.OfType<FilterAttributeFilterProvider>().First());
            FilterProviders.Providers.Add(new UnityFilterAttributeFilterProvider(container));

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        /// <summary>Disposes the Unity container when the application is shut down.</summary>
        public static void Shutdown()
        {
            // this lazy loads, so should be handled to not auto-build before disposal
            var container = Container.Current;
            container.Dispose();
        }
    }
}