﻿using RestAPI.Common.Models;
using System.Collections.Generic;
using System.Data.Entity;

namespace RestAPI.Common.Interface
{
    public interface IDatabaseContext
    {
        IDbSet<Patient> Patients { get; }
        IDbSet<Episode> Episodes { get; }


        /// <summary>
        /// checks in new data, optionally saving/flushing on issue
        /// </summary>
        /// <param name="items">the data, currently patients and episodes only</param>
        /// <param name="flush">whether to call SaveChanges </param>
        void Put(IEnumerable<IPatientOrEpisode> items, bool flush = true);
    }

}