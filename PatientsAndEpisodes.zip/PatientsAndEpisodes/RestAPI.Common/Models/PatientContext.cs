﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Collections.Generic;
using RestAPI.Common.Interface;
using System.Linq;

namespace RestAPI.Common.Models
{
    public class PatientContext : DbContext, IDatabaseContext
    {   
        public PatientContext()
            : base("PatientContext")
        {
            // not working...?
            //Database.SetInitializer<PatientContext>(init);
            Database.Initialize(true);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        public virtual IDbSet<Patient> Patients { get; set; }
        
        public virtual IDbSet<Episode> Episodes { get; set; }
        
        /// <summary>
        /// checks in new data, optionally saving/flushing on issue
        /// </summary>
        /// <param name="items">the data, currently patients and episodes only</param>
        /// <param name="flush">whether to call SaveChanges </param>
        public void Put(IEnumerable<IPatientOrEpisode> items, bool flush = true)
        {
            foreach(Patient p in items.Where(item => item is Patient))
            {
                Patients.Add(p);
            }
            
            foreach (Episode e in items.Where(item => item is Episode))
            {
                Episodes.Add(e);
            }
            
            if (flush)
            {
                SaveChanges();
            }
        }
    }
}