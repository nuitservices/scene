﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestAPI.Common.Models
{
    /// <summary>
    /// marker interface for data that is EITHER a Patient OR an Episode
    /// </summary>
    public interface IPatientOrEpisode
    {
        int ID { get; set; }
    }
}
