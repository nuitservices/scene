﻿using System;
using System.ComponentModel.DataAnnotations;

namespace RestAPI.Common.Models
{
    public class Episode : IPatientOrEpisode
    {
        [Key]
        public int ID { get; set; }

        public int PatientId { get; set; }

        public DateTime AdmissionDate { get; set; }

        public DateTime DischargeDate { get; set; }

        public string Diagnosis { get; set; }

        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false.
            if (obj == null)
            {
                return false;
            }

            if (obj is Episode)
            {
                Episode other = (Episode)obj;
                // Return true if the fields match:
                return (other.ID == ID) &&
                    (other.PatientId == PatientId) &&
                    (other.AdmissionDate == AdmissionDate) &&
                    (other.DischargeDate == DischargeDate) &&
                    (other.Diagnosis == Diagnosis);
            }

            return false;
        }
    }
}