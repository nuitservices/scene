﻿using System.Data.Entity;
using RestAPI.Common.Interface;
using System.Collections.Generic;
using System.Linq;

namespace RestAPI.Common.Models
{
    public class InMemoryPatientContext : IDatabaseContext
    {
        private readonly InMemoryDbSet<Patient> _patients = new InMemoryDbSet<Patient>();
        private readonly InMemoryDbSet<Episode> _episodes = new InMemoryDbSet<Episode>();

        public IDbSet<Patient> Patients
        {
            get { return _patients; }
        }

        public IDbSet<Episode> Episodes
        {
            get { return _episodes; }
        }


        /// <summary>
        /// checks in new data
        /// </summary>
        /// <param name="items">the data, currently patients and episodes only</param>
        /// <param name="flush">not applicable here, changes are immediate.</param>
        public void Put(IEnumerable<IPatientOrEpisode> items, bool flush = true)
        {
            foreach(IPatientOrEpisode item in items)
            {
                if (item is Patient)
                {
                    _patients.Add((Patient)item);
                }
                else if (item is Episode)
                {
                    _episodes.Add((Episode)item);
                }
            }
        }
    }
}