﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RestAPI.Common.Models
{
    public class Patient : IPatientOrEpisode
    {
        [Key]
        public int ID { get; set; }

        public string NhsNumber { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public IEnumerable<Episode> Episodes { get; set; }
    }
}