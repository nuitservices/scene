﻿using NUnit.Framework;
using RestAPI.Common.Interface;
using RestAPI.Common.Models;
using RestAPI.Common.Trunk;
using Microsoft.Practices.Unity;

namespace RestAPI.Test.Unit
{
    public class BaseTest
    {
        [SetUp]
        public void Setup()
        {
            Container.Current.RegisterType(
                typeof(IDatabaseContext), 
                typeof(InMemoryPatientContext),
                new ContainerControlledLifetimeManager());

            Container.Current.Resolve<PatientInitialiser>()
                .Seed();   
        }
    }
}
