﻿using NUnit.Framework;
using RestAPI.Common.Interface;
using RestAPI.Common.Models;
using RestAPI.Common.Trunk;
using RestAPI.Controllers;
using System.Linq;

namespace RestAPI.Test.Unit
{
    [TestFixture]
    public class WhenFindingOneEpisodePatient : BaseTest
    {
        Patient found;
        PatientsController controller;

        [SetUp]
        public void AndThePatientRequestedIsFound()
        {
            IDatabaseContext ctx = (IDatabaseContext)
                Container.Current.Resolve(typeof(IDatabaseContext), null);

            controller = (PatientsController)
                Container.Current.Resolve(typeof(PatientsController), null);

            IQueryable<Patient> ps = ctx.Patients.Where(p =>
                ctx.Episodes.Where(e => e.PatientId == p.ID)
                .Count() == 1);

            found = ps.First();
        }

        [Test]
        public void ThenPatientIsFound()
        {
            Assert.That(found, Is.Not.Null);
        }

        [Test]
        public void ThenControllerReturnsTheSameOne()
        {
            Patient also = controller.Get(found.ID);

            Assert.That(also.Episodes.Count(), Is.EqualTo(1));
            Assert.That(also.Episodes.First(), Is.EqualTo(found.Episodes.First()));

        }
    }
}
