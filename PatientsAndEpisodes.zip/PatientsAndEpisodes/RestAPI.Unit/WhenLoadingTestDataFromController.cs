﻿using Microsoft.Practices.Unity;
using NUnit.Framework;
using RestAPI.Common.Interface;
using RestAPI.Common.Models;
using RestAPI.Common.Trunk;
using RestAPI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestAPI.Test.Unit
{
    [TestFixture]
    public class WhenLoadingTestDataFromController : BaseTest
    {
        PatientsController controller;
        Patient patient1;

        [SetUp]
        public void WhenLoadingController()
        {
            var container = Container.Current;
            
            UnityWebActivator.Start();

            // force load dependencies hack
            controller = (PatientsController) container
                .Resolve(typeof(PatientsController), null);

            AndLoadingData();
        }

        void AndLoadingData()
        {
            patient1 = controller.Get(1);
        }

        [Test]
        public void ThenControllerLoadsTestPatient()
        {
            Assert.That(patient1, Is.Not.Null, "patient not loaded");
        }
    }
}