﻿using NUnit.Framework;
using RestAPI.Common.Interface;
using RestAPI.Common.Models;
using RestAPI.Common.Trunk;
using Microsoft.Practices.Unity;

namespace RestAPI.Test.Integration
{
    public class BaseTest
    {
        [SetUp]
        public void Setup()
        {
            Container.Current.Resolve<PatientInitialiser>()
                .Seed();   
        }
    }
}
