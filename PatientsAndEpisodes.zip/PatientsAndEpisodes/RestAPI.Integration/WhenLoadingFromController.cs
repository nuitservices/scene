﻿using NUnit.Framework;
using RestAPI.Controllers;
using RestAPI.Common.Models;
using RestAPI.Common.Trunk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestAPI.Test.Integration
{
    [TestFixture]
    public class WhenLoadingFromController : BaseTest
    {
        PatientsController controller;
        Patient patient1;

        [SetUp]
        public void WhenLoadingController()
        {
            UnityWebActivator.Start();
            
            controller = (PatientsController)
                Container.Current.Resolve(typeof(PatientsController), null);

            AndLoadingData();
        }

        void AndLoadingData()
        {
            patient1 = controller.Get(1);
        }

        [Test]
        public void ThenControllerLoadsPatient()
        {
            Assert.That(patient1, Is.Not.Null, "patient not loaded");
        }
    }
}
