﻿using RestAPI.Common.Models;
using RestAPI.Common.Interface;
using System.Linq;
using System.Net;
using System.Web.Http;

namespace RestAPI.Controllers
{
    public class PatientsController : ApiController
    {
        IDatabaseContext ctx;

        public PatientsController(IDatabaseContext ctx)
        {
            this.ctx = ctx;
        }

        [HttpGet]
        public Patient Get(int patientId)
        {
            var patientsAndEpisodes =
                from p in ctx.Patients
                join e in ctx.Episodes on p.ID equals e.PatientId
                where p.ID == patientId
                select new { p, e };

            if (patientsAndEpisodes.Any())
            {
                var first = patientsAndEpisodes.First().p;
                first.Episodes = patientsAndEpisodes.Select(x => x.e).ToArray();
                return first;
            }
            
            throw new HttpResponseException(HttpStatusCode.NotFound);
        }
    }
}